export const LineSVG = () => {
  return (
    <svg width="14" height="1" viewBox="0 0 14 1" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M1 0.5H13" stroke="#8E9AAB" strokeLinecap="round" />
    </svg>
  );
};
