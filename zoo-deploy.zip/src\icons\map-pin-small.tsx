import React from 'react';

type MapPinSmallProps = {
  size?: number;
  className?: string;
};

const MapPinSmall: React.FC<MapPinSmallProps> = ({ size = 20, className }) => {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 20 20"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="M17.5004 9.07407C17.5004 13.1651 12.8129 18.3333 10.0004 18.3333C7.18793 18.3333 2.50043 13.1651 2.50043 9.07407C2.50043 4.98307 5.85829 1.66666 10.0004 1.66666C14.1426 1.66666 17.5004 4.98307 17.5004 9.07407Z"
        className="stroke-primary-blue"
        strokeWidth="1.5"
      />
      <path
        d="M12.5004 9.16666C12.5004 10.5474 11.3811 11.6667 10.0004 11.6667C8.61972 11.6667 7.50043 10.5474 7.50043 9.16666C7.50043 7.78595 8.61972 6.66666 10.0004 6.66666C11.3811 6.66666 12.5004 7.78595 12.5004 9.16666Z"
        className="stroke-primary-blue"
        strokeWidth="1.5"
      />
    </svg>
  );
};

export default MapPinSmall;
