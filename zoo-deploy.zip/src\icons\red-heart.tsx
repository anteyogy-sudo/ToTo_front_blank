export const RedHeart = () => {
  return (
    <svg
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className="hover:scale-[115%] hover:opacity-80 transition-opacity"
    >
      <path
        d="M3.87118 13.6759L8.91936 18.8454C10.6088 20.5754 13.3912 20.5754 15.0806 18.8454L20.1288 13.6759C22.2904 11.4624 22.2904 7.87362 20.1288 5.66012C17.9672 3.44662 14.4626 3.44663 12.3011 5.66013C12.136 5.8292 11.864 5.8292 11.6989 5.66013C9.53736 3.44663 6.03275 3.44663 3.87118 5.66012C1.70961 7.87362 1.70961 11.4624 3.87118 13.6759Z"
        className="fill-primary-red"
      />
    </svg>
  );
};
