import React from "react";

export const WidePrimaryBlueOutlinedHeartIcon = () => {
  return (
    <svg
      width="32"
      height="32"
      viewBox="0 0 32 32"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
          d="M5.16158 17.4012L12.9194 25.3454C14.6088 27.0754 17.3912 27.0754 19.0806 25.3454L26.8384 17.4012C29.7205 14.4499 29.7205 9.66483 26.8384 6.7135C23.9563 3.76217 19.2835 3.76217 16.4014 6.7135V6.7135C16.1813 6.93893 15.8187 6.93893 15.5986 6.7135V6.7135C12.7165 3.76217 8.04367 3.76217 5.16157 6.7135C2.27947 9.66483 2.27948 14.4499 5.16158 17.4012Z"
          className="stroke-primary-gray"
          strokeWidth="2"
      />
    </svg>
  );
};