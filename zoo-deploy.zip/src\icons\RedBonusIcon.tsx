export const RedBonusIcon = () => {
  return (
    <svg
      width="24"
      height="25"
      viewBox="0 0 24 25"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <rect y="0.5" width="24" height="24" rx="12" className="fill-primary-red" />
      <path
        d="M11.3198 12.8853V14.931H12.2143C12.978 14.931 13.4436 14.5873 13.4436 13.922V13.9109C13.4436 13.2401 12.9833 12.8853 12.2038 12.8853H11.3198Z"
        fill="white"
      />
      <path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M12 20.5C16.4183 20.5 20 16.9183 20 12.5C20 8.08172 16.4183 4.5 12 4.5C7.58172 4.5 4 8.08172 4 12.5C4 16.9183 7.58172 20.5 12 20.5ZM12.6851 16.5H9.4V8.5H14.7357V10.1355H11.3198V11.4106H12.6066C14.2596 11.4106 15.4 12.3974 15.4 13.9109V13.922C15.4 15.491 14.2963 16.5 12.6851 16.5Z"
        fill="white"
      />
    </svg>
  );
};
