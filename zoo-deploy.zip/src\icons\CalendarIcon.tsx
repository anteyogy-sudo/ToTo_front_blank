export const CalendarIcon = () => {
  return (
    <svg
      width="24"
      height="25"
      viewBox="0 0 24 25"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="M8 7.5V3.5M16 7.5V3.5M7 11.5H17M5 21.5H19C20.1046 21.5 21 20.6046 21 19.5V7.5C21 6.39543 20.1046 5.5 19 5.5H5C3.89543 5.5 3 6.39543 3 7.5V19.5C3 20.6046 3.89543 21.5 5 21.5Z"
        stroke="#121212"
        strokeOpacity="0.4"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
};
