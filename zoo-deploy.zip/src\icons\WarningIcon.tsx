export const WarningSVG = () => {
    return (
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22Z" className="stroke-primary-blue" strokeWidth="2"/>
            <path d="M12 7V13" className="stroke-primary-blue" strokeWidth="2" strokeLinecap="round"/>
            <path d="M12 17C12.5523 17 13 16.5523 13 16C13 15.4477 12.5523 15 12 15M12 17V15M12 17C11.4477 17 11 16.5523 11 16C11 15.4477 11.4477 15 12 15M12 17V15" className="fill-primary-blue"/>
        </svg>

    );
};
