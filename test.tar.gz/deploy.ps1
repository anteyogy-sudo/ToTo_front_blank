param(
    [string]$Brand = "zoo"
)

$ErrorActionPreference = "Stop"

$SERVER  = "192.168.21.23"
$USER    = "oleg"
$KEY     = "$env:USERPROFILE\.ssh\my_new_key"
$REMOTE  = "/opt/zoo"
$ARCHIVE = "zoo-deploy.tar.gz"

Write-Host "== 1/4 Packing ==" -ForegroundColor Cyan
tar -czf $ARCHIVE .

Write-Host "== 2/4 Uploading ==" -ForegroundColor Cyan
scp -i $KEY $ARCHIVE "${USER}@${SERVER}:/tmp/"

Write-Host "== 3/4 Deploying on server ==" -ForegroundColor Cyan
ssh -i $KEY "${USER}@${SERVER}" @"
    mkdir -p $REMOTE
    cd $REMOTE
    tar -xzf /tmp/$ARCHIVE
    rm /tmp/$ARCHIVE
    NEXT_PUBLIC_BRAND=$Brand docker compose up -d --build 2>&1
"@

Write-Host "== 4/4 Cleanup ==" -ForegroundColor Cyan
Remove-Item $ARCHIVE -ErrorAction SilentlyContinue

Write-Host ""
Write-Host "Done! http://$SERVER`:3000" -ForegroundColor Green

